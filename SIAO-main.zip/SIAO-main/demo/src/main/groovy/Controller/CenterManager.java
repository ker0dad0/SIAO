package Controller;

public class CenterManager {
}
